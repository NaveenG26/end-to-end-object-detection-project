# signlanguage > 2024-04-08 5:19pm
https://universe.roboflow.com/signlanguage-ccdqy/signlanguage-3p94o

Provided by a Roboflow user
License: CC BY 4.0

